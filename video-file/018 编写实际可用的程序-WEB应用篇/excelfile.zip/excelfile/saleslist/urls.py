from django.urls import path
from . import views

app_name = 'saleslist'
urlpatterns = [
    path('', views.file_page, name='filepage'),
    path('getfile/', views.send_file, name='sendfile'),
]
