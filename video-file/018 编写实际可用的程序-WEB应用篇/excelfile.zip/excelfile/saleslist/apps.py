from django.apps import AppConfig


class SaleslistConfig(AppConfig):
    name = 'saleslist'
